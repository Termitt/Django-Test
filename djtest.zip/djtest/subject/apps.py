from django.apps import AppConfig


class SubjectConfig(AppConfig):
    name = 'subject'
