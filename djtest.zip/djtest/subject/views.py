from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.core.urlresolvers import reverse

from .models import Subject, Theme, Question, Answer, Test

# Здесь представления, касающиеся предметов

def subject(request):
    ''' контроллер, отвечающий за отображение списка предметов '''
    subject_list = Subject.objects.order_by('subject_text')
    context = {'subject_list': subject_list}
    return render(request, 'subject/subject.html', context)

def theme(request, subject_id):
    ''' контроллер, отвечающий за список тем по данному предмету '''
    subject = get_object_or_404(Subject, pk = subject_id)
    return render(request, 'subject/theme.html', {'subject': subject})

def test(request, subject_id, theme_id):
    ''' контроллер, отвечающий за список тестов по данной теме данного предмета '''
    theme = get_object_or_404(Theme, pk = theme_id)
    return render(request, 'subject/test.html', {'theme': theme, 'subject_id': subject_id})

def starttest(request, subject_id, theme_id, test_id):
    ''' контроллер, отвечающий за начало теста'''
    test = get_object_or_404(Test, pk = test_id)
    numquestions = len(test.question_set.all())
    request.session['true_answer_counter'] = 0     # сессионная переменная для хранения количества правильных ответов
    request.session['numquestions'] = numquestions # сессионная переменная для хранения общего количества вопросов в тесте
    return render(request, 'subject/starttest.html', {'test': test, 'subject_id': subject_id, 'theme_id': theme_id, 'question_counter': 0, 'numquestions': numquestions})

def question(request, subject_id, theme_id, test_id, question_counter):
    ''' контроллер, отвечающий за начало теста'''
    test = get_object_or_404(Test, pk = test_id)
    question = test.question_set.all()[int(question_counter)]
    question_counter = str(int(question_counter) + 1)
    #answer = question.true_answer_set.all()[int(true_answer_counter)]
    answer_list = question.answer_set.all()
    return render(request, 'subject/question.html', {'test': test, 'subject_id': subject_id, 'theme_id': theme_id, 'question_counter': question_counter, 'question': question, 'answer_list': answer_list})

def calc(request, subject_id, theme_id, test_id, question_id, question_counter):
    ''' контроллер, отвечающий за обработку ответа на текущий вопрос '''
    question = get_object_or_404(Question, pk = question_id)
    try:
        selected_answer = question.answer_set.get(pk = request.POST['answer'])
    except (KeyError, Answer.DoesNotExist):
        return render(request, 'subject/error.html', {'error_message': "Вы не выбрали ответ!"})
    else:
        if selected_answer.true_answer == True:
            request.session['true_answer_counter'] += 1
        if question_counter == str(request.session['numquestions']):
            ''' если достигнут конец теста '''
            result = request.session['numquestions']
            return HttpResponseRedirect(reverse('subject:result'))
        else:
            ''' если еще не конец теста, то переходим к следующему вопросу '''
            return HttpResponseRedirect(reverse('subject:question', args=(subject_id, theme_id, test_id, question_counter)))

def result(request):
    ''' контроллер, отвечающий за вывод результата '''
    ta = request.session['true_answer_counter']
    nq = request.session['numquestions']
    request.session['result'] = str(round((float(ta)/float(nq)) * 100, 2))+"%"
    return render(request, 'subject/result.html')
