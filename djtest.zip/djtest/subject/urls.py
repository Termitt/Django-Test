from django.conf.urls import url

from . import views

app_name = 'subject'

urlpatterns = [
    # переход по /subject/ (список предметов)
    url(r'^$', views.subject, name = 'subject'),
    # переход по /subject/5/ (список тем)
    url(r'^(?P<subject_id>[0-9]+)/$', views.theme, name='theme'),
    # переход по /subject/5/4/ (список тестов)
    url(r'^(?P<subject_id>[0-9]+)/(?P<theme_id>[0-9]+)/$', views.test, name='test'),
    # переход по /subject/5/4/2/ (стартовая страница теста)
    url(r'^(?P<subject_id>[0-9]+)/(?P<theme_id>[0-9]+)/(?P<test_id>[0-9]+)/$', views.starttest, name='starttest'),
    # переход по /subject/5/4/2/1/ (страница текущего вопроса)
    url(r'^(?P<subject_id>[0-9]+)/(?P<theme_id>[0-9]+)/(?P<test_id>[0-9]+)/(?P<question_counter>[0-9]+)/$', views.question, name='question'),
    # переход по /subject/5/4/2/1/0/calc/ (страница обработки ответа на текущий вопрос)
    url(r'^(?P<subject_id>[0-9]+)/(?P<theme_id>[0-9]+)/(?P<test_id>[0-9]+)/(?P<question_id>[0-9]+)/(?P<question_counter>[0-9]+)/calc/$', views.calc, name='calc'),
    # переход по /subject/result/ (страница результата)
    url(r'^result/$', views.result, name = 'result'),
]
