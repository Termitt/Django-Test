from django.db import models

# Здесь расположены модели для приложения, работающего с предметами

class Subject(models.Model):
    ''' модель для хранения предметов '''
    class Meta:
        verbose_name = "предмет"
        verbose_name_plural = "предметы"

    subject_text = models.CharField("Название предмета", max_length = 64)

    def __str__(self):
        return self.subject_text

class Theme(models.Model):
    ''' модель для хранения тем '''
    class Meta:
        verbose_name = "тема"
        verbose_name_plural = "темы"

    theme_text = models.CharField("Название темы", max_length = 128)
    subject = models.ForeignKey(Subject, on_delete = models.CASCADE, verbose_name = "Предмет")

    def __str__(self):
        return self.theme_text

class Test(models.Model):
    ''' модель для хранения тестов '''
    class Meta:
        verbose_name = "тест"
        verbose_name_plural = "тесты"

    test_text    = models.CharField("Название теста", max_length = 128)
    description  = models.TextField("Примечание к тесту", null = True, blank = True)
    theme = models.ForeignKey(Theme, on_delete = models.CASCADE, verbose_name = "Тема")

    def __str__(self):
        return self.test_text

class Question(models.Model):
    ''' класс для хранения вопроса '''
    class Meta:
        verbose_name = "вопрос"
        verbose_name_plural = "вопросы"

    question_text = models.CharField("Вопрос", max_length = 255)
    test = models.ForeignKey(Test, on_delete = models.CASCADE, verbose_name = "Название теста")

    def __str__(self):
        return self.question_text   

class Answer(models.Model):
    ''' класс для хранения ответа '''
    class Meta:
        verbose_name = "ответ"
        verbose_name_plural = "ответы"

    answer_text = models.CharField("Ответ", max_length = 128)
    true_answer = models.BooleanField("Верный ответ", default = False)
    question = models.ForeignKey(Question, on_delete = models.CASCADE, verbose_name = "Вопрос")

    def __str__(self):
        return self.answer_text
